/**
 * Created by Administrator on 14-7-16.
 */
exports.mvc = require('./biz/mvc');
