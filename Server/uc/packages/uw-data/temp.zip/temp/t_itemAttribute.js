module.exports = {
    "1987" : {id:1987,name:'普通属性胶囊',type:1,propertys:[[33,320],[34,160],[35,60],[36,60]],addition:0,limit:1000},
    "1988" : {id:1988,name:'高级属性胶囊',type:1,propertys:[[33,560],[34,280],[35,105],[36,105]],addition:0,limit:800},
    "1989" : {id:1989,name:'精品属性胶囊',type:1,propertys:[[33,800],[34,400],[35,150],[36,150]],addition:50,limit:100},
    "1990" : {id:1990,name:'顶级属性胶囊',type:1,propertys:[[33,1200],[34,600],[35,225],[36,225]],addition:100,limit:50},
    "1997" : {id:1997,name:'爆炸属性胶囊',type:1,addition:500,limit:10}
};